## Plane elasticity demo

This repository contains a *Mathematica* demonstration of finite element solutions to a cantilever beam under the assumptions of plane elasticity.  A CDF file is also included that can be used with the [Wolfram Player](https://www.wolfram.com/cdf-player/) without the need for *Mathematica*.
